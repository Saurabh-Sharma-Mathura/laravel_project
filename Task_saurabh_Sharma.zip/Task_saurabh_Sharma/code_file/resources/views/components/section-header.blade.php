@props(['sectionName'])
<h1 class="text-3xl text-black font-thin tracking-tighter pb-1">{{$sectionName}}</h1>
